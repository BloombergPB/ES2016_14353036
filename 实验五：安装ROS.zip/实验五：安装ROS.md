#实验五：安装ROS

@(lab5)
***
此次实验任务安装ROS，按照[ROS安装教程](http://wiki.ros.org/jade/Installation/Ubuntu)或者[中文版教程](http://wiki.ros.org/cn/jade/Installation/Ubuntu)进行安装即可。
***
一、安装步骤
1.  配置 Ubuntu 软件仓库，使其允许 "restricted"、"universe" 和 "multiverse"这三种安装模式。
>![Alt text](./1478537109693.png)

2. 给apt加入新的源
`
sudo sh -c 'echo "deb http://packages.ros.org/ros/ubuntu $(lsb_release -sc) main" > /etc/apt/sources.list.d/ros-latest.list'
`


3. 添加 keys
`
sudo apt-key adv --keyserver hkp://pool.sks-keyservers.net --recv-key 0xB01FA116
`
> ![Alt text](./1478536945430.png)
4. 确保Debian软件包索引是最新的
`
sudo apt-get update
`
5. 安装ROS的indigo版本
`
sudo apt-get install ros-indigo-desktop-full
`
> ![Alt text](./1478537922808.png)

6. 初始化rosdep
`
sudo rosdep init
rosdep update
`
> ![Alt text](./1478538044585.png)

7. 配置环境配置，配置是永久的，配置一次后，当关闭终端，再打开时，不需要再配置。
`
echo "source /opt/ros/indigo/setup.bash" >> ~/.bashrc
source ~/.bashrc
`
8. 安装 rosinstall
`
sudo apt-get install python-rosinstall
`
> ![Alt text](./1478538139608.png)

安装结束

***
二、 测试ROS
1. 打开一个终端，输入指令：
`
roscore
`
出现界面显示如下：
> ![Alt text](./1478538523389.png)

2. 打开第二个终端，输入以下指令，开启一个小乌龟界面：
`
 rosrun turtlesim turtlesim_node
 `
出现界面显示如下：
> ![Alt text](./1478538558197.png)

3.  打开第三个终端，输入以下指令，接收键盘输入，控制小乌龟移动
`
rosrun turtlesim turtle_teleop_key
`
> ![Alt text](./1478538589052.png)
 
4.  打开第四个终端，输入以下指令，可以看到ROS nodes以及Topic等图形展示：
`
rosrun rqt_graph rqt_graph
`
> ![Alt text](./1478538727250.png)

***
三、实验感想
> 这次的实验安装教程就可以成功，但是我在其中还是遇到了很多问题，比如进行到第七步配置环境变量的时候出现找不到路径的问题，一直解决不了，以至于现在我打开终端都会出现下图报错。
> ![Alt text](./1478538821617.png)
> 虽然有报错，但是测试还是可以成功。
